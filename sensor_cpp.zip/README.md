README_FILE:


PROJECT DETAILS:

Exrtaction of following features using data recieved from IMU SENSORS:

1)Calculated ROLL-PITCH-YAW Using ACCELEROMETER and MAGNETOMETER.
2)Calculated NUMBER OF STREET LIGHTS using LUX values.
3)Calculated MAXIMUM SOUND INTENSITY using SOUND values

STEPS TO RUN THE FILE:
1)Download the zip file.
2)Extract all the files in same directory.
3)Open the terminal and enter the following commands
   $ cd path_to_directory
   $make
   $make run
   $make clean.
