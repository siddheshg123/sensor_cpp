var searchData=
[
  ['sensor',['sensor',['../classsensor.html',1,'']]],
  ['sound',['sound',['../classsound.html',1,'sound'],['../classsound.html#a812758797a1d8c7e9cf2a7151b625c04',1,'sound::sound()']]],
  ['sounds',['sounds',['../fun_8cpp.html#a88ac836e9d1d7ebb584e7ef26c05d28a',1,'sounds(json j_com):&#160;fun.cpp'],['../fun_8h.html#a57b7b256eac12679ea4ff5d5ae6932fd',1,'sounds(json):&#160;fun.cpp']]]
];
