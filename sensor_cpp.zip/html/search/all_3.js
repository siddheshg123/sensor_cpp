var searchData=
[
  ['get_5fvalue',['get_value',['../classsensor.html#a91ac0bbcaba9be5d270f9e8fbaca4c0d',1,'sensor::get_value()'],['../classrpy.html#a96326a544a88cebca35505021bfdd31f',1,'rpy::get_value()']]],
  ['get_5fvalue1',['get_value1',['../classsensor.html#a035a96a4e84a6d53305054dbbaf85247',1,'sensor::get_value1()'],['../classlight.html#aa8f8a8342715ea08892f89c0f0fc1b4f',1,'light::get_value1()']]],
  ['get_5fvalue2',['get_value2',['../classsensor.html#a644efa54cbb7d3a44244500131e91bdf',1,'sensor::get_value2()'],['../classsound.html#a0f428c6dc1496da81ed0f6637e6fc256',1,'sound::get_value2()']]],
  ['gyro',['gyro',['../fun_8cpp.html#a48f008637196fb96211b05b77afb9407',1,'gyro(json j_com):&#160;fun.cpp'],['../fun_8h.html#a1974395e75189dc88c0198cd4f7a2217',1,'gyro(json):&#160;fun.cpp']]]
];
