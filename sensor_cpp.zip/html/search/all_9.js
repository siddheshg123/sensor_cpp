var searchData=
[
  ['roll',['roll',['../fun_8cpp.html#ae8645b0d11c9512ee580049f768b41cf',1,'roll(vector&lt; sensor *&gt; new_acc_vector):&#160;fun.cpp'],['../fun_8h.html#a2e0a0514fd0eca4a709fb72127e5334d',1,'roll(vector&lt; sensor *&gt;):&#160;fun.cpp']]],
  ['rpy',['rpy',['../classrpy.html',1,'rpy'],['../classrpy.html#a4f032520867bdc976165c61c12f731be',1,'rpy::rpy()']]],
  ['rpy_2ecpp',['rpy.cpp',['../rpy_8cpp.html',1,'']]],
  ['rpy_2eh',['rpy.h',['../rpy_8h.html',1,'']]]
];
