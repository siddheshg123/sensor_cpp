var searchData=
[
  ['mag',['mag',['../fun_8cpp.html#a5fdc2613359f4e1c8d2d583dd3f6ce37',1,'mag(json j_com):&#160;fun.cpp'],['../fun_8h.html#a53694eda22116952b15651861670c252',1,'mag(json):&#160;fun.cpp']]],
  ['magnet',['magnet',['../fun_8cpp.html#af9a4b1c2a9a39b1e1bc82cc234e73172',1,'magnet(vector&lt; sensor *&gt; new_mag_vector, string s):&#160;fun.cpp'],['../fun_8h.html#a5e24f45c96e5f93418c0876fc1f49829',1,'magnet(vector&lt; sensor *&gt;, string):&#160;fun.cpp']]],
  ['main',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['max_5fvolume',['max_volume',['../fun_8cpp.html#a574b1c3570381d9e6e1df3649c2c4d09',1,'max_volume(vector&lt; sensor *&gt; new_sound_vector):&#160;fun.cpp'],['../fun_8h.html#a6054cd913fbbde5e3a138e0ebcc5c52a',1,'max_volume(vector&lt; sensor *&gt;):&#160;fun.cpp']]]
];
