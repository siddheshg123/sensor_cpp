var searchData=
[
  ['accele',['accele',['../fun_8cpp.html#a0ded30e0962c8abfd051e1ac098f6414',1,'accele(json j_com):&#160;fun.cpp'],['../fun_8h.html#acfb0613c2fd39460d5ace7ac18898e9f',1,'accele(json):&#160;fun.cpp']]]
];
