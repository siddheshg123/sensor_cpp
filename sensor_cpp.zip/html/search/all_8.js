var searchData=
[
  ['pitch',['pitch',['../fun_8cpp.html#a2c1b9964e5ac0c33d11845d1b5ff9ebc',1,'pitch(vector&lt; sensor *&gt; new_acc_vector):&#160;fun.cpp'],['../fun_8h.html#a02def3c8b89691485144c31ca33a0e4b',1,'pitch(vector&lt; sensor *&gt;):&#160;fun.cpp']]]
];
