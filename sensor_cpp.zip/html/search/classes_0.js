var searchData=
[
  ['light',['light',['../classlight.html',1,'']]]
];
